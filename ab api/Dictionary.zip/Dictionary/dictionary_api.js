$(document).ready(function(){
    $('.search_input').keyup(function(enterbutton){
        if(enterbutton.keyCode == 13){
            findResults();
        }         
    });

$('.search_button').click(function(){
	findResults();
});
 });
function findResults() {

$.ajax({
	url: 'https://od-api.oxforddictionaries.com/api/v1' ,
	method: 'GET',
	data: {
	app_id: '12583b9b',
	app_key: 'b8989214b785cccba7bc364c72ca548e',
	source_lang: 'en',
	word_id: $('.search_input').val(),
	
},
	success: displayResults 
		}
 	);
}

function displayResults(reply) {
	$('#results').empty();

if (reply==0){
	$('#results').html('<p>No results found</p>');
} else {
	var myRequest = new Request('word_id');

	fetch(myRequest).then(function(response) {
  	return response.blob();
	}).then(function(myBlob) {
  	var objectURL = URL.createObjectURL(myBlob);
  	myWord.src = objectURL;
  
   $('#results').append(word_id);
});
		}
}

    // for (var i=0; i<word_id.length; i++){
    //     var image_url = word_id[i].previewURL;
    //     var word = $(document.createElement('img'));
    //     img.attr("src", image_url);
        
    //     $('#results').append(word_id);


//         var myImage = document.querySelector('img');

// fetch('word_id').then(function(reply) {
//   return reply.blob();
// }).then(function(myBlob) {
//   var objectURL = URL.createObjectURL(myBlob);
//   my.src = objectURL;
// });





	// for (var i = 0; i< reply.length; i++){
	// 	var word_url = reply[i].previewURL;
	// 	var word = $(document.createElement('word'));
	// 	word.attr('src', word_url);

	// 	$('results').append(word);


	